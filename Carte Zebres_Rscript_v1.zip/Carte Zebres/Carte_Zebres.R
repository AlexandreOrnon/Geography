setwd("/Users/ornon/Dropbox/Carte Zebres")

library(rgdal)
library(sf)
library("readxl")
library(dplyr)
library(plyr)
library(mapview) # GIS visualisation


list.files( pattern='\\.shp$')
shape <- readOGR(dsn = "codes_postaux_region.shp", layer = "codes_postaux_region")
shapesf <- st_as_sf(shape)
com_centre <- st_centroid(shapesf)
reponses <- read_excel("reponses.xlsx")
code_postal_reponses <- reponses[c(5)]
as.character(code_postal_reponses)
code_postal_reponses <- count(code_postal_reponses, vars = c("code"))
code_postal_reponses$ID <- code_postal_reponses$code
reponses_pt <- merge(x = com_centre, y = code_postal_reponses, by = "ID", all = TRUE)
zebres <- reponses_pt[ which(reponses_pt$freq >= 1), ]

zebres$Commune <- zebres$LIB 

zebres$ID <- NULL 
zebres$SURF <- NULL 
zebres$SURF <- NULL 
zebres$POP2010 <- NULL 
zebres$MEN2010 <- NULL 
zebres$LIB <- NULL
mapview(zebres)
m <- mapview(zebres)

## create standalone .html

mapshot(m, url = "zebres.html")

